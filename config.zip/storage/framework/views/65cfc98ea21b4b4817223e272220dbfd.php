<?php echo $__env->make("backend.layout.header", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


        <!-- Main Content -->
        <main class="min-h-[calc(100vh-80px)]">
            <?php echo $__env->yieldContent('content'); ?>
        </main>


<?php echo $__env->make("backend.layout.footer", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\ezeone\oz_crm\resources\views/backend/layout/app.blade.php ENDPATH**/ ?>