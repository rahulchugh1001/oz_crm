<?php $__env->startSection('title', 'Production Reports List'); ?>

<?php $__env->startSection('page-title', 'Production Reports Management'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <span class="text-slate-600">Production Reports</span>
    <i data-lucide="chevron-right" class="w-4 h-4 mx-1 text-slate-400"></i>
    <span class="font-medium text-slate-900">List</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6">
    <!-- Success Message -->
    <?php if(session('success')): ?>
    <div class="mb-6 p-4 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-3">
        <i data-lucide="check-circle" class="w-5 h-5 text-emerald-600 flex-shrink-0"></i>
        <p class="text-sm text-emerald-800"><?php echo e(session('success')); ?></p>
    </div>
    <?php endif; ?>

    <!-- Header with Add Button -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-subtle">
        <div class="p-6 border-b border-slate-200">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center">
                        <i data-lucide="file-text" class="w-5 h-5 text-white"></i>
                    </div>
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">All Production Reports</h2>
                        <p class="text-sm text-slate-500">Manage production reports and data</p>
                    </div>
                </div>
                <a href="<?php echo e(route('admin.production-reports.create')); ?>" class="inline-flex items-center gap-2 px-4 py-2 gradient-primary text-white font-semibold rounded-lg hover:shadow-lg transition-all hover:scale-105">
                    <i data-lucide="plus" class="w-4 h-4"></i>
                    <span>Add New Report</span>
                </a>
            </div>

            <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 mt-4">
                <div class="flex items-center gap-2">
                    <a href="<?php echo e(route('admin.production-reports.index', ['mode' => 'active'])); ?>" class="inline-flex items-center px-3 py-1.5 rounded-lg text-sm font-medium border <?php echo e($mode === 'active' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'); ?>">
                        Active
                    </a>
                    <a href="<?php echo e(route('admin.production-reports.index', ['mode' => 'deleted'])); ?>" class="inline-flex items-center px-3 py-1.5 rounded-lg text-sm font-medium border <?php echo e($mode === 'deleted' ? 'bg-rose-600 text-white border-rose-600' : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'); ?>">
                        Deleted
                    </a>
                    <a href="<?php echo e(route('admin.production-reports.index', ['mode' => 'all'])); ?>" class="inline-flex items-center px-3 py-1.5 rounded-lg text-sm font-medium border <?php echo e($mode === 'all' ? 'bg-slate-700 text-white border-slate-700' : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'); ?>">
                        All
                    </a>
                </div>

                <form action="<?php echo e(route('admin.production-reports.index')); ?>" method="GET" class="w-full lg:w-auto">
                    <input type="hidden" name="mode" value="<?php echo e($mode); ?>">
                    <div class="flex items-center gap-2">
                        <div class="relative w-full lg:w-80">
                            <i data-lucide="search" class="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"></i>
                            <input
                                type="text"
                                name="search"
                                value="<?php echo e($search ?? ''); ?>"
                                placeholder="Search machine, date, shift..."
                                class="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            >
                        </div>
                        <button type="submit" class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-all">
                            Search
                        </button>
                        <?php if(!empty($search)): ?>
                        <a href="<?php echo e(route('admin.production-reports.index', ['mode' => $mode])); ?>" class="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 transition-all">
                            Reset
                        </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- Production Reports Table -->
        <div class="overflow-x-auto">
            <table class="w-full text-[13px]">
                <thead class="bg-slate-50 border-b border-slate-200">
                    <tr>
                        <th class="px-3 py-2.5 text-left text-[11px] font-semibold text-slate-700 uppercase tracking-wider">ID</th>
                        <th class="px-3 py-2.5 text-left text-[11px] font-semibold text-slate-700 uppercase tracking-wider">Machine</th>
                        <th class="px-3 py-2.5 text-left text-[11px] font-semibold text-slate-700 uppercase tracking-wider">Slide Size</th>
                        <th class="px-3 py-2.5 text-left text-[11px] font-semibold text-slate-700 uppercase tracking-wider">Report Date</th>
                        <th class="px-3 py-2.5 text-left text-[11px] font-semibold text-slate-700 uppercase tracking-wider">Shift</th>
                        <th class="px-3 py-2.5 text-left text-[11px] font-semibold text-slate-700 uppercase tracking-wider">Total Achieved Set</th>
                        <th class="px-3 py-2.5 text-left text-[11px] font-semibold text-slate-700 uppercase tracking-wider">Workman</th>
                        <th class="px-3 py-2.5 text-left text-[11px] font-semibold text-slate-700 uppercase tracking-wider">Staff</th>
                        <th class="px-3 py-2.5 text-left text-[11px] font-semibold text-slate-700 uppercase tracking-wider">Status</th>
                        <th class="px-3 py-2.5 text-right text-[11px] font-semibold text-slate-700 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200">
                    <?php $__empty_1 = true; $__currentLoopData = $productionReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50 transition-colors">
                        <td class="px-3 py-2.5 text-xs text-slate-900 font-medium">#<?php echo e($report->id); ?></td>
                        <td class="px-3 py-2.5 text-xs text-slate-900 font-semibold"><?php echo e($report->machine->name ?? '-'); ?></td>
                        <td class="px-3 py-2.5 text-xs text-slate-600"><?php echo e($report->slideSize->name ?? '-'); ?></td>
                        <td class="px-3 py-2.5 text-xs text-slate-900"><?php echo e($report->report_date ? \Carbon\Carbon::parse($report->report_date)->format('d M Y') : '-'); ?></td>
                        <td class="px-3 py-2.5 text-xs text-slate-900"><?php echo e($report->shift); ?></td>
                        <td class="px-3 py-2.5 text-xs text-slate-900 font-medium"><?php echo e(($report->actual_set_shift ?? '-')); ?>/<?php echo e(($report->total_set_shift ?? '-')); ?></td>
                        <td class="px-3 py-2.5 text-xs text-slate-900"><?php echo e($report->workman_count ?? '-'); ?></td>
                        <td class="px-3 py-2.5 text-xs text-slate-900"><?php echo e($report->staff_count ?? '-'); ?></td>
                        <td class="px-3 py-2.5">
                            <?php
                                $isAchieved = ($report->total_set_shift ?? 0) > 0 && ($report->actual_set_shift ?? 0) >= ($report->total_set_shift ?? 0);
                            ?>
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium <?php echo e($isAchieved ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'); ?>">
                                <?php echo e($isAchieved ? 'Achieved' : 'Not Achieved'); ?>

                            </span>
                        </td>
                        <td class="px-3 py-2.5 text-right">
                            <div class="flex items-center justify-end gap-2">
                                <a href="<?php echo e(route('admin.production-reports.show', $report)); ?>" class="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-all" title="View">
                                    <i data-lucide="eye" class="w-3.5 h-3.5"></i>
                                </a>
                                <a href="<?php echo e(route('admin.production-reports.edit', $report)); ?>" class="p-1.5 text-amber-600 hover:bg-amber-50 rounded-lg transition-all" title="Edit">
                                    <i data-lucide="edit" class="w-3.5 h-3.5"></i>
                                </a>
                                <?php if(!$report->is_deleted): ?>
                                    <form action="<?php echo e(route('admin.production-reports.destroy', $report)); ?>" method="POST" class="inline js-swal-delete-form" data-item-name="Report #<?php echo e($report->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-all" title="Delete">
                                            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" class="px-3 py-8 text-center">
                            <div class="flex flex-col items-center gap-2">
                                <i data-lucide="inbox" class="w-12 h-12 text-slate-300"></i>
                                <p class="text-slate-500">No production reports found</p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if($productionReports->hasPages()): ?>
        <div class="px-3 py-3 border-t border-slate-200">
            <?php echo e($productionReports->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    lucide.createIcons();

    (() => {
        const deleteForms = document.querySelectorAll('.js-swal-delete-form');
        if (!deleteForms.length || typeof Swal === 'undefined') return;

        deleteForms.forEach((form) => {
            form.addEventListener('submit', async (event) => {
                event.preventDefault();
                const itemName = form.getAttribute('data-item-name') || 'this report';

                const result = await Swal.fire({
                    title: 'Delete report?',
                    text: `Are you sure you want to delete ${itemName}?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc2626',
                    cancelButtonColor: '#64748b',
                    confirmButtonText: 'Yes, delete it',
                    cancelButtonText: 'Cancel',
                });

                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\ezeone\oz_crm\resources\views/backend/production-reports/index.blade.php ENDPATH**/ ?>