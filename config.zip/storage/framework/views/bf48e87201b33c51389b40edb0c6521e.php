<!-- Sidebar -->
<div class="w-64 bg-gradient-to-b from-slate-900 to-slate-800 text-gray-200 h-screen fixed left-0 top-0 flex flex-col z-40 shadow-elevated">
    <div class="p-6 border-b border-white/10">
        <div class="flex items-center gap-3">
            <div>
                <img src="<?php echo e(asset('admin/images/ozone-logo-white.png')); ?>" alt="Logo" style="padding: 0px; height: 50px; object-fit: contain; margin-top: 2px;">
            </div>
        </div>
    </div>
    
    <nav class="flex-1 p-4 overflow-y-auto">
        <div class="space-y-1">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="w-full flex items-center gap-3 p-3 rounded-lg transition-all hover-lift <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-white/20 text-white' : 'hover:bg-white/10 text-gray-200'); ?>">
                <div class="w-8 h-8 rounded-lg <?php echo e(request()->routeIs('admin.dashboard') ? 'gradient-primary' : 'bg-white/5'); ?> flex items-center justify-center">
                    <i data-lucide="home" class="w-4 h-4 <?php echo e(request()->routeIs('admin.dashboard') ? 'text-white' : 'text-gray-400'); ?>"></i>
                </div>
                <span class="font-medium">Dashboard</span>
            </a>

            <a href="<?php echo e(route('admin.items.index')); ?>" class="w-full flex items-center gap-3 p-3 rounded-lg transition-all hover-lift <?php echo e(request()->routeIs('admin.items.*') ? 'bg-white/20 text-white' : 'hover:bg-white/10 text-gray-200'); ?>">
                <div class="w-8 h-8 rounded-lg <?php echo e(request()->routeIs('admin.items.*') ? 'gradient-primary' : 'bg-white/5'); ?> flex items-center justify-center">
                    <i data-lucide="box" class="w-4 h-4 <?php echo e(request()->routeIs('admin.items.*') ? 'text-white' : 'text-gray-400'); ?>"></i>
                </div>
                <span class="font-medium">Items</span>
            </a>

            <a href="<?php echo e(route('admin.machines.index')); ?>" class="w-full flex items-center gap-3 p-3 rounded-lg transition-all hover-lift <?php echo e(request()->routeIs('admin.machines.*') ? 'bg-white/20 text-white' : 'hover:bg-white/10 text-gray-200'); ?>">
                <div class="w-8 h-8 rounded-lg <?php echo e(request()->routeIs('admin.machines.*') ? 'gradient-primary' : 'bg-white/5'); ?> flex items-center justify-center">
                    <i data-lucide="cog" class="w-4 h-4 <?php echo e(request()->routeIs('admin.machines.*') ? 'text-white' : 'text-gray-400'); ?>"></i>
                </div>
                <span class="font-medium">Machines</span>
            </a>

            <a href="<?php echo e(route('admin.production-reports.index')); ?>" class="w-full flex items-center gap-3 p-3 rounded-lg transition-all hover-lift <?php echo e(request()->routeIs('admin.production-reports.*') ? 'bg-white/20 text-white' : 'hover:bg-white/10 text-gray-200'); ?>">
                <div class="w-8 h-8 rounded-lg <?php echo e(request()->routeIs('admin.production-reports.*') ? 'gradient-primary' : 'bg-white/5'); ?> flex items-center justify-center">
                    <i data-lucide="file-text" class="w-4 h-4 <?php echo e(request()->routeIs('admin.production-reports.*') ? 'text-white' : 'text-gray-400'); ?>"></i>
                </div>
                <span class="font-medium">Production Reports</span>
            </a>
            
            
        </div>
    </nav>
    
    <div class="p-4 border-t border-white/10">
        <div class="flex items-center gap-3 p-3 rounded-lg bg-white/5">
            <div class="w-10 h-10 rounded-full gradient-primary flex items-center justify-center">
                <i data-lucide="user" class="w-5 h-5 text-white"></i>
            </div>
            <div class="flex-1">
                <p class="font-medium text-white"><?php echo e(auth()->user()->name ?? 'John Doe'); ?></p>
                <p class="text-sm text-gray-400 capitalize"><?php echo e(auth()->user()->role ?? 'Admin'); ?></p>
            </div>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="p-1 hover:bg-white/10 rounded-lg">
                    <i data-lucide="log-out" class="w-4 h-4 text-gray-400"></i>
                </button>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\ezeone\oz_crm\resources\views/backend/layout/sidebar.blade.php ENDPATH**/ ?>